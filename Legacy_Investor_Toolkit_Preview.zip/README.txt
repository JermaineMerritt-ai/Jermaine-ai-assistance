Legacy Investor Toolkit - Preview Edition
=========================================

This ZIP includes:
- PDF (8.5x11) preview with 2 sections and clickable placeholders
- Word (.docx) version, fully editable
- Placeholder opt-in link: legacyinvestor@email.com/updates

Final version will include:
- All 4 Toolkit sections
- Live Google Sheets / MailerLite links
- Polished branded design
